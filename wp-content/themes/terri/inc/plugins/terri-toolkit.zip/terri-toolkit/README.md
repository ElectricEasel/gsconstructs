# Terri Toolkit v1.0.3

> Terri Toolkit is a plugin intended to be used with the Terri theme only. This plugin adds custom post types and shortcodes, but does not include any styles as these styles are added in the Terri theme.

## Changelog
= January 17 2017 - 1.0.3 =
* Added excerpt support option to custom post types

= November 02 2016 - 1.0.2 =
* Added accordion shortcode

= November 02 2016 - 1.0.1 =
* Added font awesome and table shortcodes

= September 26 2016 - 1.0 =
* Initial release